import { D1Database } from '@cloudflare/workers-types';

interface Env {
  DB: D1Database;
}

export async function onRequest(context) {
  const { request, env } = context;
  
  // Handle API routes
  const url = new URL(request.url);
  const path = url.pathname;
  
  // API routes
  if (path.startsWith('/api/')) {
    return handleApiRequest(request, path, env);
  }
  
  // Serve static assets
  return context.next();
}

async function handleApiRequest(request: Request, path: string, env: Env) {
  // Auth endpoints
  if (path === '/api/auth/register' && request.method === 'POST') {
    return handleRegister(request, env);
  }
  
  if (path === '/api/auth/login' && request.method === 'POST') {
    return handleLogin(request, env);
  }
  
  // Commodity endpoints
  if (path === '/api/commodities' && request.method === 'GET') {
    return handleGetCommodities();
  }
  
  // Account endpoints
  if (path === '/api/accounts/deposit' && request.method === 'POST') {
    return handleDeposit(request, env);
  }
  
  if (path === '/api/accounts/withdraw' && request.method === 'POST') {
    return handleWithdraw(request, env);
  }
  
  // Trading endpoints
  if (path === '/api/trading/execute' && request.method === 'POST') {
    return handleExecuteTrade(request, env);
  }
  
  // Report endpoints
  if (path === '/api/reports/generate' && request.method === 'POST') {
    return handleGenerateReport(request, env);
  }
  
  // Not found
  return new Response('Not Found', { status: 404 });
}

async function handleRegister(request: Request, env: Env) {
  try {
    const body = await request.json();
    const { username, password } = body;
    
    // Validate input
    if (!username || !password) {
      return new Response(
        JSON.stringify({ error: 'Username and password are required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Check if user already exists
    const existingUser = await env.DB.prepare(
      'SELECT id FROM users WHERE username = ?'
    ).bind(username).first();
    
    if (existingUser) {
      return new Response(
        JSON.stringify({ error: 'Username already exists' }),
        { status: 409, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Create new user
    const result = await env.DB.prepare(
      'INSERT INTO users (username, password_hash) VALUES (?, ?)'
    ).bind(username, password).run();
    
    const userId = result.meta.last_row_id;
    
    return new Response(
      JSON.stringify({
        id: userId,
        username,
        createdAt: new Date().toISOString()
      }),
      { status: 201, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Failed to register user' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

async function handleLogin(request: Request, env: Env) {
  try {
    const body = await request.json();
    const { username, password } = body;
    
    // Validate input
    if (!username || !password) {
      return new Response(
        JSON.stringify({ error: 'Username and password are required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Find user
    const user = await env.DB.prepare(
      'SELECT id, username, password_hash FROM users WHERE username = ?'
    ).bind(username).first();
    
    if (!user || user.password_hash !== password) {
      return new Response(
        JSON.stringify({ error: 'Invalid username or password' }),
        { status: 401, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Find or create account for user
    let account = await env.DB.prepare(
      'SELECT id, balance FROM accounts WHERE user_id = ?'
    ).bind(user.id).first();
    
    if (!account) {
      // Create new account with initial balance of 0
      const result = await env.DB.prepare(
        'INSERT INTO accounts (user_id, balance) VALUES (?, 0)'
      ).bind(user.id).run();
      
      const accountId = result.meta.last_row_id;
      account = { id: accountId, balance: 0 };
    }
    
    // Generate a simple token (in a real app, use JWT)
    const token = btoa(`${user.id}:${Date.now()}`);
    
    return new Response(
      JSON.stringify({
        token,
        user: {
          id: user.id,
          username: user.username
        },
        account: {
          id: account.id,
          balance: account.balance
        }
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Failed to log in' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

async function handleGetCommodities() {
  // This would normally fetch from Yahoo Finance API
  // For demo purposes, we'll return mock data
  const mockPrices = {
    gold: 1850.20,
    silver: 27.35,
    crude_oil: 75.80,
    refined_oil: 2.45
  };
  
  return new Response(
    JSON.stringify(mockPrices),
    { status: 200, headers: { 'Content-Type': 'application/json' } }
  );
}

async function handleDeposit(request: Request, env: Env) {
  try {
    const body = await request.json();
    const { accountId, amount } = body;
    
    // Validate input
    if (!accountId || !amount || amount <= 0) {
      return new Response(
        JSON.stringify({ error: 'Valid account ID and positive amount are required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Find account
    const account = await env.DB.prepare(
      'SELECT id, balance FROM accounts WHERE id = ?'
    ).bind(accountId).first();
    
    if (!account) {
      return new Response(
        JSON.stringify({ error: 'Account not found' }),
        { status: 404, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Update account balance
    const newBalance = account.balance + amount;
    await env.DB.prepare(
      'UPDATE accounts SET balance = ? WHERE id = ?'
    ).bind(newBalance, accountId).run();
    
    // Record transaction
    const result = await env.DB.prepare(
      'INSERT INTO transactions (account_id, type, amount) VALUES (?, ?, ?)'
    ).bind(accountId, 'deposit', amount).run();
    
    const transactionId = result.meta.last_row_id;
    
    return new Response(
      JSON.stringify({
        success: true,
        transaction: {
          id: transactionId,
          accountId,
          type: 'deposit',
          amount,
          timestamp: new Date().toISOString()
        },
        newBalance
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Failed to process deposit' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

async function handleWithdraw(request: Request, env: Env) {
  try {
    const body = await request.json();
    const { accountId, amount } = body;
    
    // Validate input
    if (!accountId || !amount || amount <= 0) {
      return new Response(
        JSON.stringify({ error: 'Valid account ID and positive amount are required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Find account
    const account = await env.DB.prepare(
      'SELECT id, balance FROM accounts WHERE id = ?'
    ).bind(accountId).first();
    
    if (!account) {
      return new Response(
        JSON.stringify({ error: 'Account not found' }),
        { status: 404, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Check if sufficient balance
    if (account.balance < amount) {
      return new Response(
        JSON.stringify({ error: 'Insufficient balance' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Update account balance
    const newBalance = account.balance - amount;
    await env.DB.prepare(
      'UPDATE accounts SET balance = ? WHERE id = ?'
    ).bind(newBalance, accountId).run();
    
    // Record transaction
    const result = await env.DB.prepare(
      'INSERT INTO transactions (account_id, type, amount) VALUES (?, ?, ?)'
    ).bind(accountId, 'withdrawal', amount).run();
    
    const transactionId = result.meta.last_row_id;
    
    return new Response(
      JSON.stringify({
        success: true,
        transaction: {
          id: transactionId,
          accountId,
          type: 'withdrawal',
          amount,
          timestamp: new Date().toISOString()
        },
        newBalance
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Failed to process withdrawal' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

async function handleExecuteTrade(request: Request, env: Env) {
  try {
    const body = await request.json();
    const { accountId, commodity, action, amount } = body;
    
    // Validate input
    if (!accountId || !commodity || !action || !amount || amount <= 0) {
      return new Response(
        JSON.stringify({ error: 'Valid account ID, commodity, action, and positive amount are required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Validate action
    if (action !== 'buy' && action !== 'sell') {
      return new Response(
        JSON.stringify({ error: 'Action must be either "buy" or "sell"' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Get current price (mock)
    const prices = {
      gold: 1850.20,
      silver: 27.35,
      crude_oil: 75.80,
      refined_oil: 2.45
    };
    
    if (!prices[commodity]) {
      return new Response(
        JSON.stringify({ error: 'Invalid commodity' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    const price = prices[commodity];
    
    // Execute trade
    const tradeResult = await env.DB.prepare(
      'INSERT INTO trades (account_id, commodity, action, quantity, price) VALUES (?, ?, ?, ?, ?)'
    ).bind(accountId, commodity, action, amount, price).run();
    
    const tradeId = tradeResult.meta.last_row_id;
    
    // Update position
    let position = await env.DB.prepare(
      'SELECT id, quantity, average_price FROM positions WHERE account_id = ? AND commodity = ?'
    ).bind(accountId, commodity).first();
    
    if (action === 'buy') {
      if (position) {
        // Update existing position
        const newQuantity = position.quantity + amount;
        const newAvgPrice = ((position.quantity * position.average_price) + (amount * price)) / newQuantity;
        
        await env.DB.prepare(
          'UPDATE positions SET quantity = ?, average_price = ? WHERE id = ?'
        ).bind(newQuantity, newAvgPrice, position.id).run();
        
        position.quantity = newQuantity;
        position.average_price = newAvgPrice;
      } else {
        // Create new position
        const positionResult = await env.DB.prepare(
          'INSERT INTO positions (account_id, commodity, quantity, average_price) VALUES (?, ?, ?, ?)'
        ).bind(accountId, commodity, amount, price).run();
        
        const positionId = positionResult.meta.last_row_id;
        position = {
          id: positionId,
          account_id: accountId,
          commodity,
          quantity: amount,
          average_price: price
        };
      }
    } else if (action === 'sell') {
      if (!position || position.quantity < amount) {
        return new Response(
          JSON.stringify({ error: 'Insufficient position quantity' }),
          { status: 400, headers: { 'Content-Type': 'application/json' } }
        );
      }
      
      // Update position
      const newQuantity = position.quantity - amount;
      
      if (newQuantity > 0) {
        await env.DB.prepare(
          'UPDATE positions SET quantity = ? WHERE id = ?'
        ).bind(newQuantity, position.id).run();
        
        position.quantity = newQuantity;
      } else {
        // Remove position if quantity is zero
        await env.DB.prepare(
          'DELETE FROM positions WHERE id = ?'
        ).bind(position.id).run();
        
        position = null;
      }
    }
    
    return new Response(
      JSON.stringify({
        success: true,
        trade: {
          id: tradeId,
          accountId,
          commodity,
          action,
          amount,
          price,
          value: amount * price,
          timestamp: new Date().toISOString()
        },
        position
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Failed to execute trade' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}

async function handleGenerateReport(request: Request, env: Env) {
  try {
    const body = await request.json();
    const { accountId } = body;
    
    // Validate input
    if (!accountId) {
      return new Response(
        JSON.stringify({ error: 'Valid account ID is required' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Find account
    const account = await env.DB.prepare(
      'SELECT id, balance FROM accounts WHERE id = ?'
    ).bind(accountId).first();
    
    if (!account) {
      return new Response(
        JSON.stringify({ error: 'Account not found' }),
        { status: 404, headers: { 'Content-Type': 'application/json' } }
      );
    }
    
    // Get trades for this account in the last week
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    const trades = await env.DB.prepare(
      'SELECT * FROM trades WHERE account_id = ? AND timestamp >= ?'
    ).bind(accountId, oneWeekAgo.toISOString()).all();
    
    // Calculate profit/loss
    let profit = 0;
    let loss = 0;
    
    for (const trade of trades.results) {
      if (trade.action === 'sell') {
        // Find the corresponding buy trades
        const buyTrades = await env.DB.prepare(
          'SELECT * FROM trades WHERE account_id = ? AND commodity = ? AND action = ?'
        ).bind(accountId, trade.commodity, 'buy').all();
        
        if (buyTrades.results.length > 0) {
          // Simple calculation - compare to average buy price
          const avgBuyPrice = buyTrades.results.reduce((sum, t) => sum + t.price, 0) / buyTrades.results.length;
          const tradeValue = trade.quantity * trade.price;
          const buyValue = trade.quantity * avgBuyPrice;
          const tradePL = tradeValue - buyValue;
          
          if (tradePL > 0) {
            profit += tradePL;
          } else {
            loss += Math.abs(tradePL);
          }
        }
      }
    }
    
    // Calculate reinvestment amount (40% of balance)
    const reinvestmentAmount = account.balance * 0.4;
    
    // Create report
    const reportResult = await env.DB.prepare(
      'INSERT INTO weekly_reports (account_id, start_date, end_date, total_trades, profit, loss, final_balance, reinvestment_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).bind(
      accountId,
      oneWeekAgo.toISOString(),
      new Date().toISOString(),
      trades.results.length,
      profit,
      loss,
      account.balance,
      reinvestmentAmount
    ).run();
    
    const reportId = reportResult.meta.last_row_id;
    
    return new Response(
      JSON.stringify({
        success: true,
        report: {
          id: reportId,
          accountId,
          startDate: oneWeekAgo.toISOString(),
          endDate: new Date().toISOString(),
          totalTrades: trades.results.length,
          profit,
          loss,
          netPL: profit - loss,
          initialBalance: account.balance - (profit - loss),
          finalBalance: account.balance,
          reinvestmentAmount,
          createdAt: new Date().toISOString()
        }
      }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: 'Failed to generate report' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
