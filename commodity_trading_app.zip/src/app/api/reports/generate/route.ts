import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Mock database for reports
// In a production app, this would be a real database
let reports: any[] = [];
let accounts: any[] = [];
let trades: any[] = [];

// API route handler for generating weekly reports
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { accountId } = body;
    
    // Validate input
    if (!accountId) {
      return NextResponse.json(
        { error: 'Valid account ID is required' },
        { status: 400 }
      );
    }
    
    // Find account
    const account = accounts.find(a => a.id === accountId);
    if (!account) {
      return NextResponse.json(
        { error: 'Account not found' },
        { status: 404 }
      );
    }
    
    // Get trades for this account in the last week
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
    
    const weeklyTrades = trades.filter(t => 
      t.accountId === accountId && 
      new Date(t.timestamp) >= oneWeekAgo
    );
    
    // Calculate profit/loss
    let profit = 0;
    let loss = 0;
    
    weeklyTrades.forEach(trade => {
      if (trade.action === 'sell') {
        // Find the corresponding buy trade
        const buyTrades = trades.filter(t => 
          t.accountId === accountId && 
          t.commodity === trade.commodity && 
          t.action === 'buy'
        );
        
        if (buyTrades.length > 0) {
          // Simple calculation - compare to average buy price
          const avgBuyPrice = buyTrades.reduce((sum, t) => sum + t.price, 0) / buyTrades.length;
          const tradeValue = trade.amount * trade.price;
          const buyValue = trade.amount * avgBuyPrice;
          const tradePL = tradeValue - buyValue;
          
          if (tradePL > 0) {
            profit += tradePL;
          } else {
            loss += Math.abs(tradePL);
          }
        }
      }
    });
    
    // Calculate reinvestment amount (40% of balance)
    const reinvestmentAmount = account.balance * 0.4;
    
    // Create report
    const reportId = reports.length + 1;
    const report = {
      id: reportId,
      accountId,
      startDate: oneWeekAgo.toISOString(),
      endDate: new Date().toISOString(),
      totalTrades: weeklyTrades.length,
      profit,
      loss,
      netPL: profit - loss,
      initialBalance: account.balance - (profit - loss),
      finalBalance: account.balance,
      reinvestmentAmount,
      createdAt: new Date().toISOString()
    };
    
    reports.push(report);
    
    return NextResponse.json({
      success: true,
      report
    });
  } catch (error) {
    console.error('Error generating report:', error);
    return NextResponse.json(
      { error: 'Failed to generate report' },
      { status: 500 }
    );
  }
}
