import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import axios from 'axios';

// Mock database for trading
// In a production app, this would be a real database
let positions: any[] = [];
let trades: any[] = [];

// Define commodity symbols
const COMMODITIES = {
  gold: 'GC=F',
  silver: 'SI=F',
  crude_oil: 'CL=F',
  refined_oil: 'RB=F'
};

// Trading algorithm parameters
const TRADING_PARAMS = {
  buyThreshold: -0.02, // Buy when price is 2% below 5-day average
  sellThreshold: 0.03, // Sell when price is 3% above 5-day average
  maxPositionSize: 0.2, // Maximum 20% of balance per position
  stopLossPercent: 0.05 // 5% stop loss
};

// Function to fetch historical prices for analysis
async function fetchHistoricalPrices(symbol: string) {
  try {
    const response = await axios.get(`https://query1.finance.yahoo.com/v8/finance/chart/${symbol}`, {
      params: {
        interval: '1d',
        range: '10d'
      }
    });
    
    const data = response.data.chart.result[0];
    const timestamps = data.timestamp;
    const quotes = data.indicators.quote[0];
    
    return timestamps.map((time: number, i: number) => ({
      timestamp: time,
      open: quotes.open[i],
      high: quotes.high[i],
      low: quotes.low[i],
      close: quotes.close[i],
      volume: quotes.volume[i]
    }));
  } catch (error) {
    console.error('Error fetching historical prices:', error);
    throw error;
  }
}

// Function to analyze market and generate trading signals
async function analyzeCommodity(commodity: string) {
  const symbol = COMMODITIES[commodity as keyof typeof COMMODITIES];
  const historicalData = await fetchHistoricalPrices(symbol);
  
  // Calculate 5-day moving average
  const prices = historicalData.map(d => d.close).filter(Boolean);
  const currentPrice = prices[prices.length - 1];
  const fiveDayAvg = prices.slice(-5).reduce((sum, price) => sum + price, 0) / 5;
  
  // Calculate price change percentage
  const priceChangePercent = (currentPrice - fiveDayAvg) / fiveDayAvg;
  
  // Generate trading signal
  let signal = 'hold';
  let confidence = 0;
  
  if (priceChangePercent <= TRADING_PARAMS.buyThreshold) {
    signal = 'buy';
    confidence = Math.min(100, Math.abs(priceChangePercent / TRADING_PARAMS.buyThreshold) * 100);
  } else if (priceChangePercent >= TRADING_PARAMS.sellThreshold) {
    signal = 'sell';
    confidence = Math.min(100, Math.abs(priceChangePercent / TRADING_PARAMS.sellThreshold) * 100);
  }
  
  return {
    commodity,
    currentPrice,
    fiveDayAvg,
    priceChangePercent,
    signal,
    confidence: Math.round(confidence)
  };
}

// API route handler for executing trades
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { accountId, commodity, action, amount } = body;
    
    // Validate input
    if (!accountId || !commodity || !action || !amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Valid account ID, commodity, action, and positive amount are required' },
        { status: 400 }
      );
    }
    
    // Validate action
    if (action !== 'buy' && action !== 'sell') {
      return NextResponse.json(
        { error: 'Action must be either "buy" or "sell"' },
        { status: 400 }
      );
    }
    
    // Validate commodity
    if (!Object.keys(COMMODITIES).includes(commodity)) {
      return NextResponse.json(
        { error: 'Invalid commodity' },
        { status: 400 }
      );
    }
    
    // Get current price
    const analysis = await analyzeCommodity(commodity);
    const price = analysis.currentPrice;
    
    // Execute trade
    const tradeId = trades.length + 1;
    const trade = {
      id: tradeId,
      accountId,
      commodity,
      action,
      amount,
      price,
      value: amount * price,
      timestamp: new Date().toISOString()
    };
    
    trades.push(trade);
    
    // Update position
    let position = positions.find(p => p.accountId === accountId && p.commodity === commodity);
    
    if (action === 'buy') {
      if (position) {
        // Update existing position
        position.quantity += amount;
        position.averagePrice = ((position.quantity - amount) * position.averagePrice + amount * price) / position.quantity;
      } else {
        // Create new position
        const positionId = positions.length + 1;
        position = {
          id: positionId,
          accountId,
          commodity,
          quantity: amount,
          averagePrice: price,
          timestamp: new Date().toISOString()
        };
        positions.push(position);
      }
    } else if (action === 'sell') {
      if (!position || position.quantity < amount) {
        return NextResponse.json(
          { error: 'Insufficient position quantity' },
          { status: 400 }
        );
      }
      
      // Update position
      position.quantity -= amount;
      
      // Remove position if quantity is zero
      if (position.quantity === 0) {
        positions = positions.filter(p => p.id !== position.id);
      }
    }
    
    return NextResponse.json({
      success: true,
      trade,
      position: position || null
    });
  } catch (error) {
    console.error('Error executing trade:', error);
    return NextResponse.json(
      { error: 'Failed to execute trade' },
      { status: 500 }
    );
  }
}
