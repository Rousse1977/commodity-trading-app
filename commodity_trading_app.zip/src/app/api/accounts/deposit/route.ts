import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Mock database for accounts
// In a production app, this would be a real database
let accounts: any[] = [];
let transactions: any[] = [];

// API route handler for deposits
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { accountId, amount } = body;
    
    // Validate input
    if (!accountId || !amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Valid account ID and positive amount are required' },
        { status: 400 }
      );
    }
    
    // Find account
    const accountIndex = accounts.findIndex(a => a.id === accountId);
    if (accountIndex === -1) {
      return NextResponse.json(
        { error: 'Account not found' },
        { status: 404 }
      );
    }
    
    // Update account balance
    accounts[accountIndex].balance += amount;
    
    // Record transaction
    const transactionId = transactions.length + 1;
    const transaction = {
      id: transactionId,
      accountId,
      type: 'deposit',
      amount,
      timestamp: new Date().toISOString()
    };
    transactions.push(transaction);
    
    return NextResponse.json({
      success: true,
      transaction,
      newBalance: accounts[accountIndex].balance
    });
  } catch (error) {
    console.error('Error processing deposit:', error);
    return NextResponse.json(
      { error: 'Failed to process deposit' },
      { status: 500 }
    );
  }
}
