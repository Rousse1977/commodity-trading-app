import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Mock database for accounts
// In a production app, this would be a real database
let accounts: any[] = [];
let transactions: any[] = [];

// API route handler for withdrawals
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { accountId, amount } = body;
    
    // Validate input
    if (!accountId || !amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Valid account ID and positive amount are required' },
        { status: 400 }
      );
    }
    
    // Find account
    const accountIndex = accounts.findIndex(a => a.id === accountId);
    if (accountIndex === -1) {
      return NextResponse.json(
        { error: 'Account not found' },
        { status: 404 }
      );
    }
    
    // Check if sufficient balance
    if (accounts[accountIndex].balance < amount) {
      return NextResponse.json(
        { error: 'Insufficient balance' },
        { status: 400 }
      );
    }
    
    // Update account balance
    accounts[accountIndex].balance -= amount;
    
    // Record transaction
    const transactionId = transactions.length + 1;
    const transaction = {
      id: transactionId,
      accountId,
      type: 'withdrawal',
      amount,
      timestamp: new Date().toISOString()
    };
    transactions.push(transaction);
    
    return NextResponse.json({
      success: true,
      transaction,
      newBalance: accounts[accountIndex].balance
    });
  } catch (error) {
    console.error('Error processing withdrawal:', error);
    return NextResponse.json(
      { error: 'Failed to process withdrawal' },
      { status: 500 }
    );
  }
}
