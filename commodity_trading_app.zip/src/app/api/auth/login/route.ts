import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Mock database for user accounts
// In a production app, this would be a real database
let users: any[] = [];
let accounts: any[] = [];
let transactions: any[] = [];
let positions: any[] = [];
let trades: any[] = [];

// API route handler for login
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password } = body;
    
    // Validate input
    if (!username || !password) {
      return NextResponse.json(
        { error: 'Username and password are required' },
        { status: 400 }
      );
    }
    
    // Find user
    const user = users.find(u => u.username === username && u.password === password);
    if (!user) {
      return NextResponse.json(
        { error: 'Invalid username or password' },
        { status: 401 }
      );
    }
    
    // Find or create account for user
    let account = accounts.find(a => a.userId === user.id);
    if (!account) {
      // Create new account with initial balance of 0
      const accountId = accounts.length + 1;
      account = {
        id: accountId,
        userId: user.id,
        balance: 0,
        createdAt: new Date().toISOString()
      };
      accounts.push(account);
    }
    
    // Generate a simple token (in a real app, use JWT)
    const token = Buffer.from(`${user.id}:${Date.now()}`).toString('base64');
    
    return NextResponse.json({
      token,
      user: {
        id: user.id,
        username: user.username
      },
      account: {
        id: account.id,
        balance: account.balance
      }
    });
  } catch (error) {
    console.error('Error logging in:', error);
    return NextResponse.json(
      { error: 'Failed to log in' },
      { status: 500 }
    );
  }
}
