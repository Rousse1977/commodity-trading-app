import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Mock database for user accounts
let users: any[] = [];
let accounts: any[] = [];
let transactions: any[] = [];
let positions: any[] = [];
let trades: any[] = [];

// API route handler for user registration
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password } = body;
    
    // Validate input
    if (!username || !password) {
      return NextResponse.json(
        { error: 'Username and password are required' },
        { status: 400 }
      );
    }
    
    // Check if user already exists
    const existingUser = users.find(user => user.username === username);
    if (existingUser) {
      return NextResponse.json(
        { error: 'Username already exists' },
        { status: 409 }
      );
    }
    
    // Create new user
    const userId = users.length + 1;
    const newUser = {
      id: userId,
      username,
      password, // In a real app, this would be hashed
      createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    
    return NextResponse.json({
      id: userId,
      username,
      createdAt: newUser.createdAt
    });
  } catch (error) {
    console.error('Error registering user:', error);
    return NextResponse.json(
      { error: 'Failed to register user' },
      { status: 500 }
    );
  }
}
