import { NextResponse } from 'next/server';
import axios from 'axios';

// Define commodity symbols
const COMMODITIES = {
  gold: 'GC=F',
  silver: 'SI=F',
  crude_oil: 'CL=F',
  refined_oil: 'RB=F'
};

// Function to fetch current prices from Yahoo Finance
async function fetchCommodityPrices() {
  try {
    const prices: Record<string, number> = {};
    
    // Fetch each commodity price
    for (const [commodity, symbol] of Object.entries(COMMODITIES)) {
      const response = await axios.get(`https://query1.finance.yahoo.com/v8/finance/chart/${symbol}`, {
        params: {
          interval: '1d',
          range: '1d'
        }
      });
      
      // Extract the current price
      const data = response.data.chart.result[0];
      const price = data.meta.regularMarketPrice;
      prices[commodity] = price;
    }
    
    return prices;
  } catch (error) {
    console.error('Error fetching commodity prices:', error);
    throw error;
  }
}

// API route handler for GET requests
export async function GET() {
  try {
    const prices = await fetchCommodityPrices();
    return NextResponse.json(prices);
  } catch (error) {
    return NextResponse.json(
      { error: 'Failed to fetch commodity prices' },
      { status: 500 }
    );
  }
}
