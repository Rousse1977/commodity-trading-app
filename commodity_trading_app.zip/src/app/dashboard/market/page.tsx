import React from 'react';
import Link from 'next/link';

export default function MarketPage() {
  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-xl font-bold">Commodity Trading</h1>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                <Link href="/dashboard" className="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                  Dashboard
                </Link>
                <Link href="/dashboard/market" className="border-indigo-500 text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                  Market
                </Link>
                <Link href="/dashboard/account" className="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                  Account
                </Link>
                <Link href="/dashboard/reports" className="border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium">
                  Reports
                </Link>
              </div>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:items-center">
              <button className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded text-sm">
                Logout
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="py-10">
        <header>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 className="text-3xl font-bold leading-tight text-gray-900">Market Analysis</h1>
          </div>
        </header>
        <main>
          <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div className="px-4 py-8 sm:px-0">
              {/* Commodity Cards */}
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-2">
                {/* Gold Card */}
                <div className="bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">Gold</h3>
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                        Buy Signal
                      </span>
                    </div>
                    <div className="mt-4">
                      <div className="flex justify-between">
                        <p className="text-sm font-medium text-gray-500">Current Price</p>
                        <p className="text-sm font-medium text-gray-900">$1,850.20</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">5-Day Average</p>
                        <p className="text-sm font-medium text-gray-900">$1,880.50</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">Change</p>
                        <p className="text-sm font-medium text-red-600">-1.61%</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">Signal Confidence</p>
                        <p className="text-sm font-medium text-green-600">80%</p>
                      </div>
                    </div>
                    <div className="mt-5">
                      <button className="w-full bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                        Buy Gold
                      </button>
                    </div>
                  </div>
                </div>

                {/* Silver Card */}
                <div className="bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">Silver</h3>
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                        Hold Signal
                      </span>
                    </div>
                    <div className="mt-4">
                      <div className="flex justify-between">
                        <p className="text-sm font-medium text-gray-500">Current Price</p>
                        <p className="text-sm font-medium text-gray-900">$27.35</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">5-Day Average</p>
                        <p className="text-sm font-medium text-gray-900">$27.42</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">Change</p>
                        <p className="text-sm font-medium text-red-600">-0.26%</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">Signal Confidence</p>
                        <p className="text-sm font-medium text-yellow-600">40%</p>
                      </div>
                    </div>
                    <div className="mt-5 grid grid-cols-2 gap-2">
                      <button className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                        Buy
                      </button>
                      <button className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                        Sell
                      </button>
                    </div>
                  </div>
                </div>

                {/* Crude Oil Card */}
                <div className="bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">Crude Oil</h3>
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                        Sell Signal
                      </span>
                    </div>
                    <div className="mt-4">
                      <div className="flex justify-between">
                        <p className="text-sm font-medium text-gray-500">Current Price</p>
                        <p className="text-sm font-medium text-gray-900">$75.80</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">5-Day Average</p>
                        <p className="text-sm font-medium text-gray-900">$73.25</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">Change</p>
                        <p className="text-sm font-medium text-green-600">+3.48%</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">Signal Confidence</p>
                        <p className="text-sm font-medium text-red-600">85%</p>
                      </div>
                    </div>
                    <div className="mt-5">
                      <button className="w-full bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                        Sell Crude Oil
                      </button>
                    </div>
                  </div>
                </div>

                {/* Refined Oil Card */}
                <div className="bg-white overflow-hidden shadow rounded-lg">
                  <div className="px-4 py-5 sm:p-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg leading-6 font-medium text-gray-900">Refined Oil</h3>
                      <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                        Sell Signal
                      </span>
                    </div>
                    <div className="mt-4">
                      <div className="flex justify-between">
                        <p className="text-sm font-medium text-gray-500">Current Price</p>
                        <p className="text-sm font-medium text-gray-900">$2.45</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">5-Day Average</p>
                        <p className="text-sm font-medium text-gray-900">$2.38</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">Change</p>
                        <p className="text-sm font-medium text-green-600">+2.94%</p>
                      </div>
                      <div className="flex justify-between mt-2">
                        <p className="text-sm font-medium text-gray-500">Signal Confidence</p>
                        <p className="text-sm font-medium text-red-600">75%</p>
                      </div>
                    </div>
                    <div className="mt-5">
                      <button className="w-full bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                        Sell Refined Oil
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Trading Positions */}
              <div className="mt-8">
                <h2 className="text-lg leading-6 font-medium text-gray-900 mb-4">Your Current Positions</h2>
                <div className="flex flex-col">
                  <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                      <div className="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                        <table className="min-w-full divide-y divide-gray-200">
                          <thead className="bg-gray-50">
                            <tr>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Commodity
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Quantity
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Avg. Price
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Current Value
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                P/L
                              </th>
                              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                Action
                              </th>
                            </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                            <tr>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">Gold</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">0.5</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">$1,845.30</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">$925.10</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-green-600">+$2.45 (+0.27%)</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <button className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded text-xs">
                                  Sell
                                </button>
                              </td>
                            </tr>
                            <tr>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">Silver</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">10</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">$27.15</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-gray-900">$273.50</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm text-green-600">+$2.00 (+0.74%)</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <button className="bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-3 rounded text-xs">
                                  Sell
                                </button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
